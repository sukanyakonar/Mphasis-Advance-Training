package exceptions;

public class RollNumberNotWithinRangeException extends Exception
{
public RollNumberNotWithinRangeException(String mssg) {
		
		super(mssg);
	}
}