import java.util.Scanner;

public class Rectangle {
	
	 float length; 
	 float width; 
	 float area; 
	 float perimeter;
	 
		public Rectangle()
		{
			this.length= length;
			this.width = width;
		}
		
		public float getlength() {
			return length;
		}
		public void setlength(float length) {
			this.length = length;
		}
		public double getwidth() {
			return width;
		}
		public void setwidth(float width) {
			this.width = width;
		}
		
	    void input() {
	        Scanner in = new Scanner(System.in);
	        System.out.print("Enter length of rectangle: ");
	        length = in.nextInt();
	        System.out.print("Enter width of rectangle: ");
	        width = in.nextInt();
	    }

	    void calculate() {
	        area = length * width;
	        perimeter = 2 * (length + width);
	    }

	    void display() {
	        System.out.println("Area of Rectangle = " + area);
	        System.out.println("Perimeter of Rectangle = " + perimeter);
	    }

	    public static void main(String args[]) {
	        Rectangle obj = new Rectangle();
	        obj.input();
	        obj.calculate();
	        obj.display();
	    }
    	
}
