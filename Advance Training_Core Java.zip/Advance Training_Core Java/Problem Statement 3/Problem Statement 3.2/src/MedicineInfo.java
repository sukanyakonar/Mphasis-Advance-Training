
public class MedicineInfo {
	
	public void displayLabel(){
	System.out.println("Company : Apollo Pharmacy");
	System.out.println("Address : Chennai");
	}
	}
class Tablet extends MedicineInfo{
	public void displayLabel(){
	System.out.println("store in a cool dry place");
	}
	}
class Syrup extends MedicineInfo{
	public void displayLabel(){
	System.out.println("Consumption as directed by the physician");
	}
	}
class Ointment extends MedicineInfo{
	public void displayLabel(){
	System.out.println("for external use only");
	}
}


