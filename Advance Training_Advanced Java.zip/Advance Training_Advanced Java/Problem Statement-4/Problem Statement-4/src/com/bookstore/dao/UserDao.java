package com.bookstore.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.bookstore.entity.User;
public class UserDao 
{
	private Connection con;

	public UserDao(Connection con) {
		this.con = con;
	}
//	method to insert in database
	public boolean saveUser(User user) {
		boolean f=false;

		try {
			String query="insert into users(first_name,address,email,user_name,password,registration_date)values (?,?,?,?,?,?)";
			PreparedStatement pstmt	=this.con.prepareStatement(query);
			pstmt.setString(1,user.getFirst_name());
			pstmt.setString(2,user.getAddress());
			pstmt.setString(3,user.getEmail());
			pstmt.setString(4,user.getUname());
			pstmt.setString(5,user.getPass());
			pstmt.setString(6,user.getRegdate());
			pstmt.executeUpdate();
			f=true;
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		return f;

	}
	public User getUserByUnameAndPassword(String uname, String password) {
		User user=null;
		try {
			String query="select * from users where user_name=? && password=?";
			
			PreparedStatement psmt=con.prepareStatement(query);
			psmt.setString(1, uname);
			psmt.setString(2, password);
			
			ResultSet set=psmt.executeQuery();
			System.out.println(uname+" "+password);
			if(set.next()) {
				user=new User();
				//data from db 
				
				user.setFirst_name(set.getString("first_name"));
				//set to user object
				user.setAddress(set.getString("address"));
				user.setEmail(set.getString("email"));
				user.setUname(set.getString("user_name"));
				user.setPass(set.getString("password"));
				user.setRegdate(set.getString("registration_date"));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
		
		
		return user;
	}
	
}
